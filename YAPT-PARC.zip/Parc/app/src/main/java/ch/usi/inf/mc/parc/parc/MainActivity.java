package ch.usi.inf.mc.parc.parc;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;


import ch.usi.inf.mc.parc.parc.fragments.AboutDialog;
import ch.usi.inf.mc.parc.parc.service.GestureService;
import ch.usi.inf.mc.parc.parc.service.RemoteService;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "MainActivity";
    private static final long HOLD_TIME = 300;
    private SensorManager mSensorManager;

    private Sensor mProximity;
    private GestureDetectorCompat mDetector;
    private RemoteService mRemoteService;

    private long lastHoverTime;

    private boolean mHoverTriggered;


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRemoteService = new RemoteService(this);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mProximity = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        mDetector = new GestureDetectorCompat(this, new GestureService(mRemoteService));
        mSensorManager.registerListener(this, mProximity, SensorManager.SENSOR_DELAY_FASTEST);
        mHoverTriggered = false;

        Log.d(TAG, "Start");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent prefintent = new Intent(this, Preferences.class);
            startActivity(prefintent);
            return true;
        }
        else if (id == R.id.action_about) {
            FragmentManager fm = getFragmentManager();
            AboutDialog dialogFragment = new AboutDialog();
            dialogFragment.show(fm, "Dialog");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mProximity, SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        this.mDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public void onSensorChanged(SensorEvent ev) {
        if (ev.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (ev.values[0] >= -0.01 && ev.values[0]<= 0.01) {
                //near
                Log.d("HOVER", "near");
                mHoverTriggered = true;
                lastHoverTime = System.currentTimeMillis();
            } else if (mHoverTriggered){
                Log.d("HOVER", "far");
                mHoverTriggered = false;
                long delay = System.currentTimeMillis() - lastHoverTime;
                if (delay > HOLD_TIME) {
                    Log.d("HOVER", "hold " + delay);
                    mRemoteService.notifyHoverHold();
                } else {
                    Log.d("HOVER", "swipe " + delay);
                    mRemoteService.notifyHoverSwipe();
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
