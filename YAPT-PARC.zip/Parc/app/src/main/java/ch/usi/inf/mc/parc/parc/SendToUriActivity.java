package ch.usi.inf.mc.parc.parc;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import ch.usi.inf.mc.parc.parc.util.UdpSender;
import ch.usi.inf.mc.parc.parc.R;

public class SendToUriActivity extends Activity {
    private static final String TAG = "SendToUriActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        final Uri uri = intent.getData();
        Log.v(TAG, "Intent received " + uri.toString());
        UdpSender udpSender = new UdpSender();
        udpSender.SendTo(this.getApplicationContext(), uri);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }
}
