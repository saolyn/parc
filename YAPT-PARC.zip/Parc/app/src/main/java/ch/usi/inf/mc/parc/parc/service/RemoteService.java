package ch.usi.inf.mc.parc.parc.service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.widget.Toast;

import ch.usi.inf.mc.parc.parc.R;
import ch.usi.inf.mc.parc.parc.util.EventHandler;


public class RemoteService implements EventHandler {
    private final Context mContext;
    private SharedPreferences mSharedPreferences;

    public RemoteService(Context context) {
        this.mContext = context;
        this.mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);;
    }

    @Override
    public void notifySingleTap() {
        String payload = mSharedPreferences.getString(mContext.getString(R.string.tap), "NOP");
        send(payload);
    }

    @Override
    public void notifyHoverSwipe() {
        String payload = mSharedPreferences.getString(mContext.getString(R.string.hover_swipe),
                "NOP");
        send(payload);

    }

    @Override
    public void notifyHoverHold() {
        String payload = mSharedPreferences.getString(mContext.getString(R.string.hover_hold),
                "NOP");
        send(payload);

    }

    @Override
    public void notifySwipeUp() {
        String payload = mSharedPreferences.getString(mContext.getString(R.string.swipe_up), "NOP");
        send(payload);
    }

    @Override
    public void notifySwipeLeft() {
        String payload = mSharedPreferences.getString(
                mContext.getString(R.string.swipe_left), "NOP");
        send(payload);
    }

    @Override
    public void notifySwipeDown() {
        String payload = mSharedPreferences.getString(
                mContext.getString(R.string.swipe_down), "NOP");
        send(payload);
    }

    @Override
    public void notifySwipeRight() {
        String payload = mSharedPreferences.getString(
                mContext.getString(R.string.swipe_right), "NOP");
        send(payload);
    }

    private void send(String payload) {
        if ("NOP".equals(payload)) {
            return;
        }
        final String host = mSharedPreferences.getString("user_ip", "");
        if ("".equals(host)) {
            Toast.makeText(mContext, "Please configure the IP address!", Toast.LENGTH_LONG).show();
            return;
        }
        final String port = mSharedPreferences.getString("user_port", "8089");
        if ("".equals(port)) {
            Toast.makeText(mContext, "Invalid port number!", Toast.LENGTH_LONG).show();
            return;
        }
        String uri = "udp://" + host + ":" + port + "/" + Uri.encode(payload);
        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse(uri));
        intent.addFlags(Intent.FLAG_ACTIVITY_PREVIOUS_IS_TOP);
        intent.addCategory(Intent.CATEGORY_DEFAULT);

        mContext.startActivity(intent);
    }
}
