package ch.usi.inf.mc.parc.parc.util;

/**
 * Created by kodikodytis on 18/12/16.
 */

public interface EventHandler {

    void notifySingleTap();
    void notifyHoverSwipe();
    void notifyHoverHold();
    void notifySwipeUp();
    void notifySwipeLeft();
    void notifySwipeDown();
    void notifySwipeRight();
}
