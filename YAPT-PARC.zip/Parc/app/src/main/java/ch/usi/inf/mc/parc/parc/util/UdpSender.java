package ch.usi.inf.mc.parc.parc.util;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.net.*;

import ch.usi.inf.mc.parc.parc.R;

public class UdpSender {
    private static final String TAG = "UdpSender";


    final Handler toastHandler = new Handler();

    public void SendTo(final Context context, final Uri uri) {

        if (uri == null) {
            return;
        }

        String msg = Uri.decode(uri.getLastPathSegment());
        if(msg == null) {
            return;
        }

        byte[] msgBytes = msg.getBytes();
        final byte[] buf = msgBytes;

        Log.d(TAG, "send: " + new String(msgBytes));

        new Thread(new Runnable() {
            public void run() {
                try {
                    InetAddress serverAddress = InetAddress.getByName(uri.getHost());
                    //Log.v(getString(R.string.app_name), serverAddress.getHostAddress());
                    DatagramSocket socket = new DatagramSocket();
                    if (!socket.getBroadcast()) {
                        socket.setBroadcast(true);
                    }

                    DatagramPacket packet = new DatagramPacket(buf, buf.length, serverAddress,
                            uri.getPort());

                    socket.send(packet);
                    socket.close();

                } catch (final IOException e) {
                    toastHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(context, e.toString(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
